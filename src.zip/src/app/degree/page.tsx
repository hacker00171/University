export default function DegreePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-6">Degree</h1>
      <p className="text-[#2CD9FF]">Under Development</p>
    </div>
  );
}
