import abbreviations from '../abb_majors.json';

type AbbreviationType = 'general_major' | 'narrow_major' | 'major';

export interface MajorNameDisplay {
  label: string;  // Abbreviated or original name for display
  fullName: string;  // Original name for hover text
}

export const getMajorAbbreviation = (majorName: string, type: AbbreviationType): string => {
  // Get the appropriate abbreviation mapping based on type
  const abbreviationMap = abbreviations[type];
  
  // Return the abbreviated form if it exists, otherwise return the original name
  return abbreviationMap[majorName] || majorName;
};

export const getMajorDisplayInfo = (majorName: string, type: AbbreviationType): MajorNameDisplay => {
  return {
    label: getMajorAbbreviation(majorName, type),
    fullName: majorName
  };
};
