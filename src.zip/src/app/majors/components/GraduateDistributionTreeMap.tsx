import React, { ReactElement } from 'react';
import {
  ResponsiveContainer,
  Treemap,
  Tooltip,
} from 'recharts';

interface Props {
  generalMajor: string | null;
  onMajorSelect?: (majorName: string) => void;
}

interface TreemapContentProps {
  x: number;
  y: number;
  width: number;
  height: number;
  index: number;
  name: string;
}

const GraduateDistributionTreeMap: React.FC<Props> = ({ generalMajor, onMajorSelect }) => {
  // Only show when no specific major is selected
  if (generalMajor) return null;

  const data = [
    {
      name: 'Engineering and Technology',
      size: 25,
      color: '#22c55e', // green
    },
    {
      name: 'Health Sciences',
      size: 23,
      color: '#3b82f6', // blue
    },
    {
      name: 'Business and Management',
      size: 17,
      color: '#ec4899', // pink
    },
    {
      name: 'Social Sciences',
      size: 19,
      color: '#f97316', // orange
    },
    {
      name: 'Arts and Humanities',
      size: 14,
      color: '#8b5cf6', // purple
    },
  ];

  const handleClick = (majorName: string) => {
    if (onMajorSelect) {
      onMajorSelect(majorName);
    }
  };

  const renderContent = (props: TreemapContentProps): ReactElement => {
    const { x, y, width, height, index, name } = props;
    return (
      <g>
        <rect
          x={x}
          y={y}
          width={width}
          height={height}
          style={{
            fill: data[index]?.color,
            stroke: '#0f172a',
            strokeWidth: 2,
            strokeOpacity: 1,
            cursor: 'pointer'
          }}
          onClick={() => handleClick(name)}
        />
        {width > 50 && height > 50 && (
          <text
            x={x + width / 2}
            y={y + height / 2 - 12}
            textAnchor="middle"
            fill="#ffffff"
            fontSize={16}
            fontWeight="bold"
            style={{
              textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
              paintOrder: 'stroke',
              stroke: '#000000',
              strokeWidth: 2,
              strokeLinecap: 'round',
              strokeLinejoin: 'round',
              cursor: 'pointer'
            }}
            onClick={() => handleClick(name)}
          >
            {name}
          </text>
        )}
        {width > 50 && height > 50 && (
          <text
            x={x + width / 2}
            y={y + height / 2 + 12}
            textAnchor="middle"
            fill="#ffffff"
            fontSize={16}
            style={{
              textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
              paintOrder: 'stroke',
              stroke: '#000000',
              strokeWidth: 2,
              strokeLinecap: 'round',
              strokeLinejoin: 'round'
            }}
          >
            {`${data[index]?.size}%`}
          </text>
        )}
      </g>
    );
  };

  return (
    <div className="bg-gradient-to-r from-[#1a2657] to-[#1a2657]/90 p-6 rounded-lg col-span-2">
      <h3 className="text-white text-lg mb-4">Graduate Distribution</h3>
      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <Treemap
            data={data}
            dataKey="size"
            stroke="#0f172a"
            fill="#4f46e5"
            content={renderContent as any}
          >
            <Tooltip
              content={({ payload }) => {
                if (payload && payload.length > 0) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-[#0a1230] border border-[#2e365f] rounded-md p-2">
                      <p className="text-white">{data.name}</p>
                      <p className="text-gray-400">{`${data.size}% of graduates`}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
          </Treemap>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default GraduateDistributionTreeMap; 