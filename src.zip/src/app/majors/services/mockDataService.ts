import mockData from '../major_mock/majorlevel_mock_data.json';

export const loadMockData = () => {
  return mockData.majorlevel;
};

export const getMajorLevelData = (
  generalMajor?: string | null,
  narrowMajor?: string | null,
  specificMajor?: string | null
) => {
  const data = mockData.majorlevel;

  if (!generalMajor) {
    return data.overall;
  }

  if (generalMajor && !narrowMajor) {
    return data[generalMajor]?.overall;
  }

  if (generalMajor && narrowMajor && !specificMajor) {
    return data[generalMajor]?.[narrowMajor]?.overall;
  }

  if (generalMajor && narrowMajor && specificMajor) {
    return data[generalMajor]?.[narrowMajor]?.[specificMajor];
  }

  return null;
};

export const getGeneralMajors = () => {
  return Object.keys(mockData.majorlevel)
    .filter(key => key !== 'overall');
};

export const getNarrowMajors = (generalMajor: string) => {
  const majorData = mockData.majorlevel[generalMajor];
  if (!majorData) return [];
  return Object.keys(majorData)
    .filter(key => key !== 'overall');
};

export const getSpecificMajors = (generalMajor: string, narrowMajor: string) => {
  const majorData = mockData.majorlevel[generalMajor]?.[narrowMajor];
  if (!majorData) return [];
  return Object.keys(majorData)
    .filter(key => key !== 'overall');
}; 